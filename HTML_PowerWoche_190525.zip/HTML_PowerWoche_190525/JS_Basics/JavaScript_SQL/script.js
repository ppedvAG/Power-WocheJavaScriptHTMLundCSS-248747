const sql = require('mssql/msnodesqlv8');

const config = {
    user: '',
    server: '',
    database: "Northwind",
    options: {
        trustServerCertificate: false,
        trustedConnection: true
    },
    driver: 'msnodesqlv8'
};

async function runQuery() {
    try {
        await sql.connect(config);
        const result = await sql.query`SELECT TOP 1 * FROM Customers`;
        console.log(result.recordset);
    } 
    catch (err) {
        console.error("Fehler", err);
    }
    finally {
        await sql.close();
    }
}

runQuery();